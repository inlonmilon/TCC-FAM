<footer>
        <div id="socialContato">
            <div id="redeSocial">
                <h3>Nossas redes sociais</h3>
                <a href="https://www.instagram.com/feitoamaopontocom/">Instagram</a>
                <a href="/">Whatsapp</a>
            </div>
            <div id="contato">
                <h3>Contato</h3>
                <a href="/">(11)96914-1984</a>
                <a href="/">feitoamao@gmail.com</a>
            </div>
        </div>
        <div id="footerDireitos">
            <p>todos os direitos reservados</p>
        </div>
    </footer>